﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileUploader
{
    public class FileUploadComponent
    {
        IDictionary<string, Func<bool>> _columnValidators = null;

        private IReader _filereader;
       
        public FileUploadComponent(string file)
        {
            _filereader = ReaderFactory(file);
            //  _filereader = filereader;
            
        }

        private IReader ReaderFactory(string file)
        {
            switch(Path.GetExtension(file))
                {
                    case "xlsx":
                    return new ExcelReader();
                    
                    case "csv":
                    return new CsvReader();

                 }
            throw new Exception("FileType Not Supported");
        }

        public IList<IList<string>> GetRecords(int numberOfColumns =0, IDictionary<string, Func<bool>> columnValidators=null )
        {
            IList<IList<string>> records= _filereader.ReadRecords();
            IList<string> columns = records[0];
            if(numberOfColumns!=0 && columns.Count!=numberOfColumns)
            {
                throw new ArrayTypeMismatchException();
            }
            if(columnValidators!=null )
            {
                foreach(string columnName in columnValidators.Keys)
                {
                    int index = columns.IndexOf(columnName);
                    if (index == -1)
                        throw new NotSupportedException();
                    for(int row=1;row<records.Count;row++)
                    {

                        if (!columnValidators[columnName].Invoke())
                            throw new ArgumentException();
                    }
                }
            }
            return records;
        }
    }
}
