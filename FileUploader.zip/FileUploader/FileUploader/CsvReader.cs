﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileUploader
{
    public class CsvReader : IReader
    {
        public IList<IList<string>> ReadRecords()
        {
            throw new NotImplementedException();
        }
    }
}
