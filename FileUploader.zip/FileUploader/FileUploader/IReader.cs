﻿using System.Collections.Generic;

namespace FileUploader
{
    public interface IReader
    {
        IList<IList<string>> ReadRecords();


    }
}